# QNB Türkiye — Typical Ticket Size

- **Minimum Typical Ticket:** USD 100,000
- **Maximum Typical Ticket:** USD 80,000,000
- **Note for GreenHope Pilots:** For smaller pilot tranches ($50K–$250K), explore technical assistance, innovation hubs, or municipal/intermediary on-lending facilities.
