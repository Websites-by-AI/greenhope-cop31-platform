# Akbank — Geographic Focus

- Türkiye
